$('document').ready(function () {
    $('#tabs').tabs();
    $(".accordion").accordion({
        collapsible: true,
        active: false,
        heightStyle: "content"
    });
})
